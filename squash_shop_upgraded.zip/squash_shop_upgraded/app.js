
const PRODUCTS = JSON.parse(`[{"id": "12CAR12524", "slug": "tecnifibre-carboflex-125-x-top-v2", "name": "Tecnifibre Carboflex 125 X-TOP V2", "brand": "Tecnifibre", "price": 199.99, "weight": "125 g", "img": "https://www.tecnifibre.com/medias/sys_master/h5f/hb6/8870779829470.jpg", "url": "https://www.tecnifibre.com/en/p/12CAR12524.html", "video": "t3iYBkkLLB4", "desc": "Pro-level carbon racket with X-TOP aerodynamics for fast swings and excellent control."}, {"id": "FX125PL", "slug": "dunlop-fx-125-pro-lite", "name": "Dunlop FX 125 Pro Lite", "brand": "Dunlop", "price": 249.0, "weight": "~125 g", "img": "https://us.dunlopsports.com/medias/sys_master/images/images/hcf/h53/8795761022238.png", "url": "https://us.dunlopsports.com/dunlop/squash/rackets/fx/fx-125-pro-lite-squash-racket/10351958.html", "video": "mHbgzXcrrRU", "desc": "Maneuverable frame with explosive power \u2014 popular among intermediate and advanced players."}, {"id": "vapor115", "slug": "harrow-vapor-115", "name": "Harrow Vapor 115", "brand": "Harrow", "price": 225.0, "weight": "115 g", "img": "https://www.harrowsports.com/cdn/shop/products/VAPOR115_BLUE_PRODUCT_IMAGE.png?v=1669999999", "url": "https://www.harrowsports.com/products/harrow-vapor-115-squash-racquet", "video": "voueLcZpPho", "desc": "All-time best seller; blend of power and control used by PSA pros."}, {"id": "rawpro20", "slug": "karakal-raw-pro-2-0", "name": "Karakal Raw Pro 2.0 (Joel Makin)", "brand": "Karakal", "price": 179.0, "weight": "120 g", "img": "https://completeeq.com/cdn/shop/products/RawPro20_BlackBlue_1024x.jpg?v=1670000000", "url": "https://completeeq.com/Karakal-Raw-Pro-2-0-Joel-Makin-Signature-Squash-Racket-Black-455400", "video": "DWoAgsyMgc0", "desc": "Signature racket with balanced feel and a 14x18 string pattern for power and control."}, {"id": "bag01", "slug": "double-racket-bag", "name": "Double Racket Bag", "brand": "Generic", "price": 69.0, "weight": "N/A", "img": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1000&auto=format&fit=crop&q=80", "url": "#", "video": "", "desc": "Padded bag for two rackets and accessories."}, {"id": "balls01", "slug": "pro-balls-pair", "name": "Pro Bounce Squash Balls (Pair)", "brand": "Dunlop", "price": 14.99, "weight": "N/A", "img": "https://images.unsplash.com/photo-1526403224743-3b7c0c5f8b3e?w=800&auto=format&fit=crop&q=80", "url": "#", "video": "", "desc": "Double yellow dot tournament balls."}, {"id": "shoes01", "slug": "courtgrip-pro", "name": "CourtGrip Pro Shoes", "brand": "Generic", "price": 119.95, "weight": "N/A", "img": "https://images.unsplash.com/photo-1528701800489-476b0c3a0a7e?w=1000&auto=format&fit=crop&q=80", "url": "#", "video": "", "desc": "Non-marking sole and breathable upper for lateral support."}, {"id": "grip01", "slug": "tacky-overgrip-5pk", "name": "Tacky Overgrip (Pack of 5)", "brand": "Generic", "price": 7.5, "weight": "N/A", "img": "https://images.unsplash.com/photo-1545235617-9465a20b28c0?w=800&auto=format&fit=crop&q=80", "url": "#", "video": "", "desc": "Thin, tacky overgrip to improve feel and reduce slippage."}]`);

function $(s){return document.querySelector(s)}
function $all(s){return Array.from(document.querySelectorAll(s))}

function formatPrice(n){return '€'+n.toFixed(2)}

function renderProducts(list){
  const container = $('#products');
  container.innerHTML = '';
  list.forEach(p=>{
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <img src="${p.img}" alt="${p.name} photo" onerror="this.style.objectFit='cover';this.src='https://via.placeholder.com/400x300?text=Image'"/>
      <h3>${p.name}</h3>
      <div class="meta">${p.brand} • ${p.weight}</div>
      <p class="desc">${p.desc}</p>
      <div class="actions">
        <a class="btn" href="${p.url}" target="_blank" rel="noopener">View product</a>
        <button class="ghost" data-id="${p.id}">Quick view</button>
      </div>
    `;
    container.appendChild(card);
  });
}

function openModal(product){
  const modal = $('#modal');
  const body = $('#modalBody');
  let media = '';
  if(product.video){
    media = `<div class="media"><img src="${product.img}" alt=""><iframe src="https://www.youtube.com/embed/${product.video}" allow="autoplay; encrypted-media" allowfullscreen title="Review video"></iframe></div>`;
  } else {
    media = `<div class="media"><img src="${product.img}" alt=""></div>`;
  }
  body.innerHTML = `<h2>${product.name}</h2><p class="meta">${product.brand} • ${product.weight} • ${formatPrice(product.price)}</p>${media}<p style="margin-top:10px">${product.desc}</p><div style="display:flex;gap:8px;margin-top:12px"><a class="btn" href="${product.url}" target="_blank">View product page</a><button id="closeModalBtn" class="ghost">Close</button></div>`;
  modal.setAttribute('aria-hidden','false');
}

document.addEventListener('click', (e)=>{
  if(e.target && e.target.matches('.ghost')){
    const id = e.target.dataset.id;
    const product = PRODUCTS.find(p=>p.id===id);
    if(product) openModal(product);
  }
  if(e.target && (e.target.id==='closeModal' || e.target.id==='closeModalBtn' || e.target.id==='closeModal')){
    $('#modal').setAttribute('aria-hidden','true');
    $('#modalBody').innerHTML = '';
  }
  if(e.target && e.target.id==='reset'){ $('#search').value=''; $('#filterBrand').value='all'; $('#maxPrice').value=300; $('#maxPriceVal').textContent='300'; applyFilters(); }
});

document.addEventListener('DOMContentLoaded', ()=>{
  renderProducts(PRODUCTS);
  $('#search').addEventListener('input', applyFilters);
  $('#filterBrand').addEventListener('change', applyFilters);
  $('#maxPrice').addEventListener('input', ()=>{ $('#maxPriceVal').textContent = $('#maxPrice').value; applyFilters(); });
});

function applyFilters(){
  const q = $('#search').value.trim().toLowerCase();
  const brand = $('#filterBrand').value;
  const maxP = parseFloat($('#maxPrice').value);
  let list = PRODUCTS.filter(p=> p.price <= maxP);
  if(brand !== 'all') list = list.filter(p=>p.brand === brand);
  if(q) list = list.filter(p=> (p.name+' '+p.desc+' '+p.brand).toLowerCase().includes(q));
  renderProducts(list);
}
