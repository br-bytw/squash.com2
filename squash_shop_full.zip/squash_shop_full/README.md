# RacketRack — Demo Static Site

This demo contains 50 placeholder products with locally embedded SVG images. Ready for GitHub Pages deployment.